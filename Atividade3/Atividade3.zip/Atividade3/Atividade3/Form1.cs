﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double Altura, Peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura))
            {
                errorProvider1.SetError(txtAltura, "Numero Inválido");
                txtAltura.Focus();
            }
            else
            {
                errorProvider1.SetError(txtPeso, "");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Altura == 0)
            {
                txtImc.Text = "tu é baixinha mas nem tanto né";
            }
            else
            {
                IMC = Peso / Math.Pow(Altura, 2);
                IMC = Math.Round(IMC, 1);
                if (IMC >= 40)
                {
                    txtImc.Text = "Obesidade Mórbida [" + IMC.ToString() + "]";
                }
                else if (IMC >= 30)
                {
                    txtImc.Text = "Obesidade [" + IMC.ToString() + "]";
                }
                else if (IMC >= 25)
                {
                    txtImc.Text = "Sobrepeso [" + IMC.ToString() + "]";
                }
                else if (IMC >= 18.5)
                {
                    txtImc.Text = "Normal [" + IMC.ToString() + "]";
                }
                else
                {
                    txtImc.Text = "Subpeso [" + IMC.ToString() + "]";
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtPeso.Text, out Peso))
            {
                errorProvider1.SetError(txtPeso, "Numero Inválido");
                txtPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(txtPeso, "");
            }
        }
    }
}
