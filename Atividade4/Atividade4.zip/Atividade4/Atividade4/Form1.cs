﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        string tipoTringulo;

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado2.Text, out lado2))
            {
                errorProvider1.SetError(txtLado2, "Texto Inválido!");
                txtLado2.Clear();
                txtLado2.Focus();
            }
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado3.Text, out lado3))
            {
                errorProvider1.SetError(txtLado3, "Texto Inválido!");
                txtLado3.Clear();
                txtLado3.Focus();
            }
        }

        private void txtLado1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if ((lado1 >= (lado2 + lado3)) || (lado2 >= (lado1 + lado3)) || (lado3 >= (lado2 + lado1)))
            {
                MessageBox.Show("Este não é um triangulo válido!");
            }
            else
            {
                if ((lado1 == lado2) && (lado2 == lado3))
                {
                    MessageBox.Show("Este é um triangulo válido!\nSeu triangulo é EQUILÁTERO!");
                }
                else if (lado1 != lado2 && lado2 != lado3 && lado3 != lado1)
                {
                    MessageBox.Show("Este é um triangulo válido!\nSeu triangulo é ESCALENO!");
                }
                else
                {
                    MessageBox.Show("Este é um triangulo válido!\nSeu triangulo é ISÓSCELES!");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado1.Text, out lado1))
            {
                errorProvider1.SetError(txtLado1, "Texto Inválido!");
                txtLado1.Clear();
                txtLado1.Focus();
            }

        }
    }
}
