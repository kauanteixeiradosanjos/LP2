﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[3, 2];
            double media1 = 0;
            double media2 = 0;

            for (int p = 0; p <= 2; p++)
            {
                listBox.Items.Add($"{p+1}º Pessoa: ");
                for (int f = 0; f <= 1; f++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Insira sua nota de 0 a 10 para o {f + 1}º filme: ", $"Pessoa n.º {p + 1}"), out notas[p, f]) || (notas[p, f] < 0 || notas[p, f] > 10))
                    {
                        if (notas[p, f] > 10 || notas[p, f] < 0)
                        {
                            MessageBox.Show("Insira um valor de 0 a 10!");
                        }
                        else
                        {
                            MessageBox.Show("Resposta Inválida!");
                        }
                        f--;
                    }
                    else
                    {
                        listBox.Items.Add($"Nota do filme {f + 1}: {notas[p, f]}");
                        if (f == 0)
                        {
                            media1 += notas[p, f];
                        }
                        else
                        {
                            media2 += notas[p, f];
                        }
                    }
                }
                listBox.Items.Add("------------------------------------------------------------");
            }
            MessageBox.Show("Calculos Finalizados");
            media1 = media1 / 3;
            media2 = media2 / 3;
            listBox.Items.Add($"Média 1º filme: {media1.ToString("N2")}");
            listBox.Items.Add($"Média 2º filme: {media2.ToString("N2")}");
            listBox.Items.Add($"===============================================================");
            
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox.Items.Clear();
        }
    }
}
