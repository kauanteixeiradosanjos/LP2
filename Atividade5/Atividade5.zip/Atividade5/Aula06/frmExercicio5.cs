﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula06
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2, numS;

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out num1))
            {
                errorProvider1.SetError(txtNum1, "Valor Inválido!");
                txtNum1.Clear();
                txtNum1.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum2.Text, out num2))
            {
                errorProvider1.SetError(txtNum2, "Valor Inválido!");
                txtNum2.Clear();
                txtNum2.Focus();
            }
        }

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (num2 < num1)
            {
                int numEx = num1;
                txtNum1.Text = txtNum2.Text;
                txtNum2.Text = numEx.ToString();
                MessageBox.Show("Invertendo maior número com o menor");
                int.TryParse(txtNum1.Text, out num1);
                int.TryParse(txtNum2.Text, out num2);

            }
            Random NumS = new Random();
            numS = NumS.Next(num1, num2 + 1);
            MessageBox.Show("Numero Sorteado: " + numS);
        }
    }
}
