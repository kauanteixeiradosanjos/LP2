﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox($"Digite o {i+1}º nome ", "Entrada de Dados");
                if (string.IsNullOrWhiteSpace(nomes[i]))
                {
                    MessageBox.Show("Dados Inválidos!");
                    i--;
                }
                else
                {
                    auxiliar = nomes[i];
                    auxiliar = auxiliar.Replace(" ", "");
                    tamanhos[i] = auxiliar.Length;
                    listBox1.Items.Add($"O nome {nomes[i]} tem {tamanhos[i]} caracteres. \n");
                }
            }



        }
    }
}
