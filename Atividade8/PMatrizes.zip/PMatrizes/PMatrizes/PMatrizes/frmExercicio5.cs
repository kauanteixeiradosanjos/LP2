﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] respostas = new char[30, 10];
            char[] gabarito = new char[10] { 'A', 'A', 'B', 'C', 'E', 'D', 'A', 'B', 'C', 'C' };

            for (int aluno = 0; aluno < 40; aluno++)
            {
                for (int i = 0; i < 10; i++)
                {
                    if (!char.TryParse(Interaction.InputBox($"Digite a resposta do aluno {aluno + 1} para a questão {i + 1}:", "Entrada de Dados"), out respostas[aluno, i]) || (respostas[aluno, i] != 'A' && respostas[aluno, i] != 'B' && respostas[aluno, i] != 'C' && respostas[aluno, i] != 'D' && respostas[aluno, i] != 'E'))
                    {
                        MessageBox.Show("Resposta inválida!");
                        i--;
                    }
                    else
                    {
                        if (respostas[aluno, i] != gabarito[i])
                        {
                            lstBox.Items.Add($"O aluno {aluno + 1} errou a questão {i + 1}! Era {gabarito[i]} e ele escolheu {respostas[aluno, i]}");
                        }
                        else
                        {
                            lstBox.Items.Add($"O aluno {aluno + 1} acertou a questão {i + 1}! Era {gabarito[i]} e escolheu {respostas[aluno, i]}");
                        }

                        if (i == 9)
                            lstBox.Items.Add("");
                    }
                }
            }
        }
    }
}
