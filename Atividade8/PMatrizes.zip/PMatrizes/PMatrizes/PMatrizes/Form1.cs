﻿using System;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = null;
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número: ",
                                                 "Entrada de Dados",
                                                 "");
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() {"Ana", "André", "Beatriz", "João",
                                                "Joana", "Otávio", "Marcelo", "Thaís"};
            Lista.Remove("Otávio");
            string auxiliar = "";
            foreach(String nome in Lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            double media = 0;
            string auxiliar = "";
            string saida = "";
            for (int i = 0; i < Notas.GetLength(0); i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite  a nota {j + 1} do aluno {i + 1}", "Entrada de dados");

                    if (!Double.TryParse(auxiliar, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado inválido");
                        j--;
                    }
                    else
                    {
                        media += Notas[i, j];
                    }

                }
                saida += $"Aluno: {i + 1}: Média:{(media / 3).ToString("N2")} \n";
                media = 0;
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existente");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existente");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }
    }
}
